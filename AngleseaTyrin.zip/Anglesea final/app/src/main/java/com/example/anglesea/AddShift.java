package com.example.anglesea;

public class AddShift {


    private int id;
    private String shift_type;
    private String shift_start_date;
    private String shift_end_date;
    private String shift_start_time;
    private String shift_end_time;
    private String shift_name;


    public int getId() { return id;}

    public String getShift_type() { return shift_type;}

    public String getShift_start_date() { return shift_start_date;}

    public String getShift_end_date() { return shift_end_date; }

    public String getShift_start_time() { return shift_start_time;}

    public String getShift_end_time() { return shift_end_time;}

    public String getShift_name() { return shift_name;}
}
